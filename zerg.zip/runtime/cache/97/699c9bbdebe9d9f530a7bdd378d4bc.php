<?php
//000000007200s:120:"{"session_key":"\/sFkInTEab6PreFsEJP9Fg==","expires_in":7200,"openid":"octTu0F1eakU_ACsF-JtnlfZfNpE","uid":1,"scope":16}";
?>
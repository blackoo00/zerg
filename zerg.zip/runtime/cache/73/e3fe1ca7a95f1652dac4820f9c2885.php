<?php
//000000007200s:119:"{"session_key":"6Z62oFgxrdpv0fKvZv5CQA==","expires_in":7200,"openid":"octTu0F1eakU_ACsF-JtnlfZfNpE","uid":1,"scope":16}";
?>
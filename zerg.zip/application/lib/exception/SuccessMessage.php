<?php
/**
 * Created by Robin.
 * User: Administrator
 * Date: 2017/9/19 0019
 * Time: 下午 9:17
 */

namespace app\lib\exception;


class SuccessMessage
{
    public $code = 201;
    public $msg = 'OK';
    public $errorCode = '0';
}
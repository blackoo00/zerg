<?php
/**
 * Created by Robin.
 * User: Administrator
 * Date: 2017/9/20 0020
 * Time: 下午 9:12
 */

namespace app\lib\enum;


class ScopeEnum
{
    const User = 16;

    const Super = 32;
}
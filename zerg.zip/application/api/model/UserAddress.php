<?php
/**
 * Created by Robin.
 * User: Administrator
 * Date: 2017/9/19 0019
 * Time: 下午 9:47
 */

namespace app\api\model;


class UserAddress extends BaseModel
{
    protected $hidden = ['id','delete_time','user_id'];

}
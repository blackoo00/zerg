<?php
/**
 * Created by Robin.
 * User: Administrator
 * Date: 2017/9/29 0029
 * Time: 下午 9:10
 */

namespace app\api\model;


class OrderProduct extends BaseModel
{

}
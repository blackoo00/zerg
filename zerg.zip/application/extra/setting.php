<?php
/**
 * Created by Robin.
 * User: Administrator
 * Date: 2017/8/31 0031
 * Time: 下午 10:55
 */
return [
  'img_prefix' => 'http://z.cn/images',
  'token_expire_in' => 7200
];
<?php
/**
 * Created by Robin.
 * User: Administrator
 * Date: 2017/9/13 0013
 * Time: 下午 10:19
 */

return [
    'token_salt' => 'HjkasHAKS23rasdR',
    'pay_back_url' => 'http:://z.cn/api/:version/pay/notify',
    'workerman_url' => 'http://127.0.0.1:2121/'
    //Ngrok(将本地服务映射到WEB：不建议用)
];